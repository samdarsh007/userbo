from telethon import events
import asyncio
from userbot.utils import lightning_cmd
from userbot import CMD_HELP
@borg.on(lightning_cmd(pattern=r"ophack", outgoing=True))
async def hapy(event):
      a="Starting Op hack😎⚡ [/]"
      await event.edit(a)
      b="Starting Op Hack😎⚡ [\]"
      await event.edit(b)
      await asyncio.sleep(2)
      c="Connecting to telegram servers 😎⚡ [/]"
      await asyncio.sleep(1)
      await event.edit(c) 
      d="Conneced to telegram [✓] connecting to @Rishisuperyo [/]"
      await event.edit(d)
      e="Connecting to @Rishisuperyo ✅ \n ■□□□□  \n [/]"
      await event.edit(e)
      f="Connecting to @Rishisuperyo ✅ \n □■□□□  \n [\]"
      await event.edit(f)
      await asyncio.sleep(1)
      await event.edit(e)
      await event.edit(f)
      g="Connected [✓] ⚡ \n Now finding **GHOST KEYS ✍️ **[/]"
      h="Finding**GHOST KEYS** [\]"
      i="** GHOST KEYS** FOUNDED [✓]"
      await event.edit(g)
      await asyncio.sleep(3)
      await event.edit(h)
      await asyncio.sleep(1)
      await event.edit(i)
      await asyncio.sleep(1)
      j="MASKING DOMAIN ■□□□□ [/]"
      await event.edit(j)
      await asyncio.sleep(1)
      k="MASKING DOMAIN □■□□□ [\]"
      await event.edit(k)
      await asyncio.sleep(1)
      op="MASKING DOMAIN □□■□□  [/]"
      await event.edit(op)
      await asyncio.sleep(1)
      yo="MASKING DOMAIN □□□■□  [\]"
      await event.edit(yo)
      await asyncio.sleep(1)
      re="MASKING DOMAIN □□□□■  [/]"
      await event.edit(re)
      await asyncio.sleep(1)
      au="[DONE ✓]\n SDCARD/STORAGE/TELEGRAM DATA IS HACKED SUCCESSFUL 🔥😎⚡\n removing all ghost keys"
      await event.edit(au)
      await asyncio.sleep(1)
      wu="REMOVED ALL THE GHOST KEYS\n` NOW PAY $100 TO MY MASTER `[TO GET ALL UR INFORMATION BACK OR 😂😂😂 I WILL TAKE😂😂😎 ](https://telegra.ph/file/061e9a5e2408bbe992b96.jpg)`AND POST TO EVERYBODY`"
      await event.edit(wu)
      
      
     
