#Plugin by @Rishisuperyo
#Animation by Rishisuperyo
#usage .lightning

from telethon import events
import asyncio
from userbot.utils import lightning_cmd

from userbot import CMD_HELP
@borg.on(lightning_cmd(pattern=r"lightning"))
async def hapy(event):


     a="ㅤㅤ  █\n         █\n        █\n       █\n      █░░░░░░█\n                        █\n                        █\n                       █\n                     █\n\n`⚡️⚡️⚡️⚡️⚡️⚡️⚡️⚡️⚡️⚡️⚡️⚡️\nPANDA-USERBOT IS OP⚡️\n_______________________________`"
     await event.edit(a)
