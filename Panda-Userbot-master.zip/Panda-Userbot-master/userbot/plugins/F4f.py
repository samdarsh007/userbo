#salle dalle agar isko kang mara to tere boob gand ek krdunga bsdk 
#haa tu hi teko hi bol rha machhar ki jhatt


import asyncio
import random
from userbot import ALIVE_NAME
from userbot.utils import lightning_cmd
#--Constants--#
sed1 = "https://telegra.ph/file/9102e0041cf2bacffc4a8.mp4"
sed2 = "https://telegra.ph/file/2034b44685abbc5d8db4d.mp4"
sed3 = "https://telegra.ph/file/c7f8f00729fc4147ad8d6.mp4"
sed4 = "https://telegra.ph/file/f5c968e0dd5bf01748678.mp4"
sed5 = "https://telegra.ph/file/026f3b4776af1f3277614.mp4"
sed6 = "https://telegra.ph/file/3593c809b7dcc17090b6c.mp4"
sed = "https://telegra.ph/file/f29468b5fba0ad146bae2.mp4"
DEFAULTUSER = str(ALIVE_NAME) if ALIVE_NAME else "вℓα¢к ℓιgнтηιηg"
remd = bot.me.id
cap = f"Yeah My Friend This Suprise is for you\nThanks for Being my Friend, I am Blessed With a friend like you✨\n                           ~[{DEFAULTUSER}](tg://user?id={remd})"
#--over--#

@borg.on(lightning_cmd(pattern=r"(hfd|friend|friends)$", outgoing=True))
async def _(event):
    if event.fwd_from:
        return
    await event.edit("Hii..!\nI found My Friend In that Account And this is for him\nAnd i feel like wishing him on this awesome day.")
    await asyncio.sleep(10)
    s = random.randrange(1, 20)
    if s == 1:
        await event.edit("With your presence in my life, my life has illuminated with new hope. You are a wonderful soul who has taught me the real meaning of friendship. \nWishing you a warm Happy Best Friend Day.")
    if s == 2:
        await event.edit(
            "When we met first you were sweet, gradually you became sweeter and now you are the sweetest person I know. You are my best friend for life. \nHappy Best Friend Day."
        )
    if s == 3:
        await event.edit(
            "Time and distance are important in every relationship. But with a friend like you, who lives in my heart, we will never be separated by distance because we are connected at heart. \nHappy Best Friend Day."
        )
    if s == 4:
        await event.edit("When you have someone whom you can call any day, any time…. you know you are blessed. \nHappy Best Friend Day.")
    if s == 5:
        await event.edit("You are someone I can count on in every step of my life. May our beautiful friendship lasts forever! \nHappy Best Friend Day.")
    if s == 6:
        await event.edit(
            "Thank you for never letting me do the stupid things alone. This just proves what a great friend you are to me. \nHappy Best Friend Day."
        )
    if s == 7:
        await event.edit("Not many things in life make me happy. But you are an exception. \nHappy Best Friend Day.")
    if s == 8:
        await event.edit("I am one of those lucky individuals who have gotten to experience the meaning of true friendship. \nHappy Best Friend Day.")
    if s == 9:
        await event.edit(
            "Some people are so special in our lives that it’s hard to imagine existing in a universe without them.\nHappy Best Friend Day."
        )
    if s == 10:
        await event.edit(
            "Thank you for being my bundle of joy. Thank you for being supportive and kind and for believing in me when no one else did.\nHappy Best Friend Day."
        )
    if s == 11:
        await event.edit(
            "Don’t make friends who are comfortable to be with. Make friends who will force you to lever yourself up.\nHappy FriendShip Day. "
        )
    if s == 12:
        await event.edit(
            "The most beautiful discovery true friends make is that they can grow separately without growing apart.\nHappy FriendShip Day. "
        )
    if s == 13:
        await event.edit(
            "Life is partly what we make it, and partly what it is made by the friends we choose.\nHappy FriendShip Day. "
        )
    if s == 14:
        await event.edit(
            "A real friend is one who walks in when the rest of the world walks out.\nHappy FriendShip Day. "
        )    
    if s == 15:
        await event.edit(
            "A friend is someone who understands your past, believes in your future, and accepts you just the way you are.\nHappy FriendShip Day. "
        )    
    if s == 16:
        await event.edit(
            "Lots of people want to ride with you in the limo, but what you want is someone who will take the bus with you when the limo breaks down.\nHappy FriendShip Day. "
        )
    if s == 17:
        await event.edit(
            "To the world, you may be just one person, but to one person you may be the world.\nHappy FriendShip Day. "
        )
    if s == 18:
        await event.edit(
            "A friend is one who overlooks your broken fence and admires the flowers in your garden.\nHappy FriendShip Day. "
        )
    if s == 19:
        await event.edit(
            "There’s not a word yet for old friends who’ve just met.\nHappy FriendShip Day. "
        ) 
    if s == 20:
        await event.edit(
            "A friend who understands your tears is much more valuable than a lot of friends who only know your smile.\nHappy FriendShip Day. "
        )
        await asyncio.sleep(5)
    await bot.send_message(event.chat_id, "Please Stay Awake For a While one more Parcel Coming")
    await asyncio.sleep(10)
    f = random.randrange(1, 7)    
    
    
    if f == 1:
        await bot.send_file(
         event.chat_id, file=sed1,caption=cap, link_preview=False
        )
    if f == 2:
        await bot.send_file(
         event.chat_id, file=sed2 ,caption=cap, link_preview=False   
        )        
    if f == 3:
        await bot.send_file(
         event.chat_id, file=sed3 ,caption=cap, link_preview=False 
        )        
    if f == 4:
        await bot.send_file(
         event.chat_id, file=sed4 ,caption=cap, link_preview=False
        )        
    if f == 5:
        await bot.send_file(
         event.chat_id, file=sed5 ,caption=cap, link_preview=False
        )
    if f == 6:
        await bot.send_file(
         event.chat_id, file=sed6 ,caption=cap, link_preview=False 


        )
    if f == 7:
        await bot.send_file(
         event.chat_id, file=sed ,caption=cap, link_preview=False  
        )        
