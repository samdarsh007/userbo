 
import os
from userbot import ALIVE_NAME 
MASTER = str(ALIVE_NAME) if ALIVE_NAME else "INFINITE"
NAME = os.environ.get("BOT_NICK_NAME")
BOT =  = str(NAME) if NAME else "PANDA-USERBOT"
#op 
Infinite = "[INFINITE](https://t.me/<YourUsrname>)"
OP = "[PANDA-USERBOT](https://github.com/NovaGaming1964/Panda-Userbot.)"
OKAY = "[SUPPORT GROUP](https://t.me/<later>)"
#itna test h aur aage krte h
#test successful raha ab aage 
ALIVE = "PANDA-USERBOT IS ON 🔥 FIRE 🔥" 
USERBOT = " HELLO MASTER MY NAME IS PANDA BOT I AM THE BEST USERBOT 💝"
EMOJI = "⚡"
#yrr isko apne bot me aply krne se pehle mere se pooch lena ok
